load('config.js');
function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    var browser = Engine.newBrowser();
    browser.launch(url, 10000);
    var doc = browser.html();
    browser.close();
    if (doc) {
        var list = [];
        var el = doc.select(".works-chapter-list a");
        if (el.size() === 0) {
            el = doc.select(".works-chapter-item a");
        }
        el.forEach(e => {
            list.push({
                name: e.text(),
                url: e.attr("href"),
                host: BASE_URL,
            });
        });
        return Response.success(list.reverse());
    }
    return null;
}