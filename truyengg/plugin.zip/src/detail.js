load('config.js');
function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    var doc = fetchRetry(url);
    if (doc) {
        var imgEl = doc.select(".book_avatar img").first();
        var cover = imgEl ? (imgEl.attr("src") || imgEl.attr("data-src") || imgEl.attr("data-fb") || "") : "";
        if (cover && cover.startsWith("//")) {
            cover = "http:" + cover;
        }

        let genres = [];
        doc.select(".book-genres a").forEach(e => {
            genres.push({
                title: e.text(),
                input: e.attr('href').replace(BASE_URL, ''),
                script: "gen.js"
            });
        });

        var author = doc.select(".book-counts li:contains(Tác giả) .book-counts__value").text();
        if (!author) author = doc.select(".book-counts li:contains(Tác Giả) .book-counts__value").text();
        
        var status = doc.select(".book-counts li:contains(Tình trạng) .book-counts__value").text();
        if (!status) status = doc.select(".book-counts li:contains(Trạng thái) .book-counts__value").text();
        
        var view = doc.select(".book-counts li:contains(Lượt xem) .book-counts__value").text();
        var follow = doc.select(".book-counts li:contains(Theo dõi) .book-counts__value").text();

        const infoBook = [
            "Tác giả: " + author,
            "Trạng thái: " + status,
            "Lượt xem: " + view,
            "Theo dõi: " + follow
        ];

        return Response.success({
            name: doc.select("h1[itemprop=name]").text(),
            cover: cover,
            host: BASE_URL,
            author: author,
            description: doc.select("div.story-detail-info").html(),
            detail: infoBook.join("<br>"),
            ongoing: status.indexOf("Đang Cập Nhật") >= 0 || status.indexOf("Đang tiến hành") >= 0,
            genres: genres
        });
    }

    return null;
}