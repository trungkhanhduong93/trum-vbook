let BASE_URL = 'https://truyenggvn.com';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

function fetchRetry(url) {
    let doc = Http.get(url).html();
    if (doc) return doc;
    
    // Fallback to browser
    let browser = Engine.newBrowser();
    browser.launch(url, 10000);
    doc = browser.html();
    browser.close();
    return doc;
}
