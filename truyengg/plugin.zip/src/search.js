load('config.js');
function execute(key, page) {
    if (!page) page = '1';
    var url = BASE_URL + "/tim-kiem/trang-" + page + ".html?q=" + key;
    var browser = Engine.newBrowser();
    browser.launch(url, 10000);
    var doc = browser.html();
    browser.close();
    if (doc) {
        var novelList = [];
        
        var next = "";
        var nextActive = doc.select(".page_redirect p.active").first();
        if (nextActive) {
            var nextParent = nextActive.parent().next();
            if (nextParent) {
                next = nextParent.select("p").text();
            }
        }
        
        var items = doc.select(".list_grid li");
        if (items.size() === 0) {
            items = doc.select(".list_grid.grid li");
        }
        
        items.forEach(e => {
            var imgEl = e.select(".book_avatar img").first();
            var cover = "";
            if (imgEl) {
                cover = imgEl.attr("data-fb") || imgEl.attr("src") || imgEl.attr("data-src") || "";
            }
            if (cover && cover.startsWith("//")) {
                cover = "http:" + cover;
            }
            
            var aEl = e.select(".book_name h3 a").first();
            var name = aEl ? aEl.text() : "";
            var link = aEl ? aEl.attr("href") : "";
            
            if (name && link) {
                novelList.push({
                    name: name,
                    link: link,
                    description: e.select(".last_chapter a").text(),
                    cover: cover,
                    host: BASE_URL
                });
            }
        });
        return Response.success(novelList, next);
    }

    return null;
}