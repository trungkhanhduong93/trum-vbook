load('config.js');
function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    var browser = Engine.newBrowser();
    browser.launch(url, 10000);
    var doc = browser.html();
    browser.close();
    if (doc) {
        var imgs = doc.select(".chapter_content img");
        if (imgs.size() === 0) {
            imgs = doc.select(".page-chapter img");
        }
        var data = [];
        imgs.forEach(e => {
            var link = e.attr("data-original") || e.attr("src") || e.attr("data-src") || "";
            if (link) {
                if (link.startsWith("//")) {
                    link = "http:" + link;
                }
                data.push({link: link});
            }
        });
        return Response.success(data);
    }
    return null;
}