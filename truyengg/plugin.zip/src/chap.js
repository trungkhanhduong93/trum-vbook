load('config.js');
function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    var doc = fetchRetry(url);
    if (doc) {
        var imgs = doc.select(".chapter_content img");
        if (imgs.size() === 0) {
            imgs = doc.select(".page-chapter img");
        }
        var data = [];
        imgs.forEach(e => {
            var link = e.attr("data-original") || e.attr("src") || e.attr("data-src") || "";
            if (link) {
                if (link.startsWith("//")) {
                    link = "http:" + link;
                }
                data.push({link: link});
            }
        });
        return Response.success(data);
    }
    return null;
}