let BASE_URL = "https://doctruyen3qui14.pro";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}